# ABPVN Script
![ABPVN Logo](http://abpvn.com/icon.png)
## User script hỗ chặn quảng cáo mở rộng tính năng cho trình duyệt

### Cần cài đặt một trình quản lý user script để cài đặt và sử dụng

**Tiện ích mở rộng khuyến cáo:**
 * [Violent Monkey](https://chrome.google.com/webstore/detail/violentmonkey/jinjaccalgkegednnccohejagnlnfdag) cho Chrome
 * [Violent Monkey](https://addons.mozilla.org/en-US/firefox/addon/violentmonkey/) cho FireFox
## Link cài đặt trên [Greasy Fork](https://greasyfork.org/vi/scripts/9099-abpvn-adsblock)