#!/bin/bash
sh commit.sh
git push