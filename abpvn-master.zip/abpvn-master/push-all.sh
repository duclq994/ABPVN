#!/bin/bash
git push --all
sleep 5
sh pull.sh