#!/bin/bash
cd ..
sh push.sh
sleep 5
sh pull.sh