﻿# [ABPVN - Bộ lọc quảng cáo cho người việt](https://abpvn.com)
ABPVN - Vietnamese adblock filter list
## [Facebook fanpage](https://www.facebook.com/abpvn.org)

## [Support forum](https://voz.vn/t/abpvn-chan-quang-cao-cho-nguoi-viet.25778/)

## LICENSE: 
Under **GNU GPLv3**, detail see [LICENSE](LICENSE)

Made with ♥ by hoangrio